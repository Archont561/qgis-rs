



nose2 --help
IF %ERRORLEVEL% NEQ 0 exit /B 1
nose2-3.6 --help
IF %ERRORLEVEL% NEQ 0 exit /B 1
exit /B 0
