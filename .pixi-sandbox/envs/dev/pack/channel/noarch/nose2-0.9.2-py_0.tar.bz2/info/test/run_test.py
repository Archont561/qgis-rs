print("import: 'nose2'")
import nose2

print("import: 'nose2.plugins'")
import nose2.plugins

print("import: 'nose2.plugins.loader'")
import nose2.plugins.loader

print("import: 'nose2.tests'")
import nose2.tests

print("import: 'nose2.tests.functional'")
import nose2.tests.functional

print("import: 'nose2.tests.unit'")
import nose2.tests.unit

print("import: 'nose2.tools'")
import nose2.tools

