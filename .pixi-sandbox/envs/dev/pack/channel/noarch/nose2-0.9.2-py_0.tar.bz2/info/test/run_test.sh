

set -ex



nose2 --help
nose2-3.6 --help
exit 0
